import { Component } from '@angular/core';

@Component({
  selector: 'first',
  template: '<second></second><h2 style="color:red;position:absolute;">My First Component content {{angtitle}}</h2>'  
})
export class FirstComponent {
    angtitle =" dynamic test";
}