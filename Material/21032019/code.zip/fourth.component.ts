import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fourth',
  template: `
    <p>
      fourth works!
    </p>
  `,
  styleUrls: ['./fourth.component.css']
})
export class FourthComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
