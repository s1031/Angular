import { Component } from '@angular/core';

@Component({
  selector: 'angcli',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  providers: []
})
export class AppComponent {
  title = 'angcliproj1';
  myname: string = "Srinivas";
  duration:number=30;
  online:boolean=false;
  topics:string[]=["Typescript","Compoents","Modules","Databinding","Pipes"];
  addtop(val){
    console.log("My Input field value " + val);
    this.topics.unshift(val);
    
  }
  deletetopic(){
    //this.topics=[];
    //this.topics.splice(3,1);
    this.topics.splice(2,this.topics.length);
  }
}
